import './Header.css';

function Header(){
    return(
        <div className="Header">
                <h1>React documentation page</h1>
                <h3>Learn React</h3>
        </div>
    );
}

export default Header;